"""Stop hook: enforce the /monitor-hpc exit contract.

Reads a Stop-hook payload on stdin (Claude Code's hook input), and if
the most recent user message was a ``/monitor-hpc`` invocation, checks
that the agent's reply ends with the required ``armed:`` line. Returns
a ``decision: block`` JSON if the line is missing so the agent is
re-prompted to comply with the slash command's exit contract.

Hook input shape (per Claude Code docs):

    {
      "session_id": "...",
      "transcript_path": "/path/to/session.jsonl",
      "cwd": "...",
      "permission_mode": "default",
      "hook_event_name": "Stop",
      "stop_reason": "end_turn|max_tokens|tool_use|stop_sequence",
      "output": "<assistant text, possibly empty>",
      "tool_uses": [...]
    }

The transcript is a JSONL file the hook reads itself. Each line is one
message envelope; ``role`` is ``user`` / ``assistant`` and ``content``
is either a string or a list of content blocks.

Output:

    {} or no output                          -> allow stop
    {"decision": "block", "reason": "..."}   -> block stop with reason

Wire-up: see :func:`hpc_agent.hooks.monitor_armed_check.settings_entry`
or run ``hpc-agent hook-install`` to add it to ~/.claude/settings.json.
"""

from __future__ import annotations

import json
import re
import shlex
import sys
from pathlib import Path
from typing import Any

__all__ = [
    "ARMED_RE",
    "USER_INVOCATION_RE",
    "is_monitor_armed_command",
    "main",
    "settings_entry",
]

# Pattern enforced by the monitor-hpc spec. Mechanism is one of cron / loop / none
# (ScheduleWakeup is intentionally absent — it is not a documented public Claude
# Code tool).
ARMED_RE = re.compile(
    r"^armed:\s+(cron|loop|none)\s+run_id=\S+\s+cadence=\d+s\s+reason=",
    re.MULTILINE,
)

USER_INVOCATION_RE = re.compile(r"(?:^|\s)/monitor-hpc(?:\s|$)")


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    """Return parsed records from *path*; ignore parse errors line-by-line."""
    out: list[dict[str, Any]] = []
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return out
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(entry, dict):
            out.append(entry)
    return out


def _content_text(content: Any) -> str:
    """Flatten a message's ``content`` field to plain text.

    Claude Code transcripts use either a bare string or the Anthropic
    block format (a list of ``{"type": "text", "text": "..."}`` and
    other block types). Tool-use / tool-result blocks are skipped.
    """
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return ""
    texts: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            texts.append(str(block.get("text", "")))
    return "\n".join(texts)


def _last_message_of_role(transcript: list[dict[str, Any]], role: str) -> str:
    for entry in reversed(transcript):
        if entry.get("role") == role:
            return _content_text(entry.get("content"))
    return ""


def _find_paired_assistant_for_invocation(
    transcript: list[dict[str, Any]],
    user_pattern: re.Pattern[str],
) -> tuple[str, str]:
    """Find the (user_text, assistant_text) pair around the most recent
    user message matching *user_pattern*.

    The naive "last user + last assistant" approach silently picks the
    wrong pair when the most recent user message isn't the
    ``/monitor-hpc`` turn. Walk the transcript in order, remembering the
    most recent matching user index, then return the LAST assistant
    message produced *before the next user message* — i.e. the agent's
    final response in the same turn. Returning the FIRST assistant
    message instead misses arming text that the agent typically appends
    after its tool-use round-trip (v3 BUG-6V3-4). If no match, return
    ("", "").
    """
    last_match_idx = -1
    last_match_text = ""
    for i, entry in enumerate(transcript):
        if entry.get("role") != "user":
            continue
        text = _content_text(entry.get("content"))
        if user_pattern.search(text):
            last_match_idx = i
            last_match_text = text
    if last_match_idx < 0:
        return "", ""
    last_assistant_text = ""
    for entry in transcript[last_match_idx + 1 :]:
        role = entry.get("role")
        if role == "user":
            break
        if role == "assistant":
            last_assistant_text = _content_text(entry.get("content"))
    return last_match_text, last_assistant_text


# The module the Stop hook runs. The *identity* of the hook is this
# module name, not the full command string — the interpreter prefix
# varies by install (see ``_default_command``), so the installer matches
# on this token to recognise and upgrade entries from older versions.
_HOOK_MODULE = "hpc_agent.hooks.monitor_armed_check"


def _default_command() -> str:
    """Return the Stop-hook command pinned to the *installing* interpreter.

    Claude Code runs hook commands through a shell using the OS ``PATH``.
    A bare ``python`` there is rarely the environment ``hpc_agent`` is
    installed into — the venv may not be activated, or ``PATH`` may point
    at the system Python — so the hook dies with ``ModuleNotFoundError``
    and silently stops enforcing the /monitor-hpc contract.
    ``sys.executable`` is the interpreter running the installer, which by
    construction can import ``hpc_agent``; pinning to it makes the hook
    fire regardless of ``PATH`` or venv-activation state.

    The path is POSIX-formatted (forward slashes) and shell-quoted: hooks
    run under a POSIX shell even on Windows, and the interpreter path
    routinely contains spaces.
    """
    return f"{shlex.quote(Path(sys.executable).as_posix())} -m {_HOOK_MODULE}"


def is_monitor_armed_command(command: str) -> bool:
    """True if *command* invokes this Stop hook, ignoring the interpreter.

    The installer uses this to recognise — and upgrade in place — entries
    written by older versions that hard-coded a bare ``python``.
    """
    return _HOOK_MODULE in command


def settings_entry(*, command: str | None = None) -> dict[str, Any]:
    """Return the JSON entry for ~/.claude/settings.json's ``hooks.Stop`` array.

    Each element of a hook-event array is a *group* object — ``{"hooks":
    [<command hook>, ...]}`` — not a bare command hook. Returning the
    group shape directly is what makes the installed entry valid; an
    older version of this function returned the bare ``{"type":
    "command", ...}`` hook, which Claude Code rejects with
    ``hooks.Stop.0.hooks: Expected array, but received undefined`` and
    then skips the entire settings file.

    With *command* omitted the hook is pinned to the current interpreter
    via :func:`_default_command`, so it runs even when the venv isn't on
    ``PATH``. Pass *command* to override (e.g. a wrapper script).
    """
    if command is None:
        command = _default_command()
    return {"hooks": [{"type": "command", "command": command}]}


def main() -> int:
    """Hook entry point. Read stdin, decide block-or-allow, exit 0."""
    raw = sys.stdin.read() or "{}"
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        # Malformed input from Claude Code is not the agent's fault.
        # Allow stop; this hook is enforcement, not validation of the host.
        return 0
    if not isinstance(payload, dict):
        return 0

    transcript_path = payload.get("transcript_path")
    transcript: list[dict[str, Any]] = []
    if isinstance(transcript_path, str) and transcript_path:
        transcript = _read_jsonl(Path(transcript_path))

    # Find the (user, assistant) pair around the most recent
    # ``/monitor-hpc`` invocation rather than the most recent user +
    # most recent assistant independently. Without this pairing a
    # session whose latest user message is an unrelated follow-up
    # would either skip enforcement (false negative) or block a turn
    # that isn't responding to /monitor-hpc (false positive).
    user_text, paired_assistant_text = _find_paired_assistant_for_invocation(
        transcript, USER_INVOCATION_RE
    )
    if not user_text:
        # No /monitor-hpc invocation anywhere in the transcript.
        return 0

    inline_output = payload.get("output")
    assistant_text = ""
    if isinstance(inline_output, str) and inline_output.strip():
        assistant_text = inline_output
    if not assistant_text:
        assistant_text = paired_assistant_text

    if ARMED_RE.search(assistant_text):
        return 0  # contract met

    decision = {
        "decision": "block",
        "reason": (
            "/monitor-hpc spec violation: every invocation must emit a final "
            "line of the form `armed: <cron|loop|none> run_id=<X> cadence=<Y>s "
            'reason="<short>"`. Don\'t hand-author this line — call '
            "`hpc-agent decide-monitor-arm --spec <state>` and copy the "
            "envelope's `data.armed_line` verbatim as the very last line of "
            "your response (the primitive also emits `data.cron_create_args` "
            'ready to pass to CronCreate when arm == "cron").'
        ),
    }
    print(json.dumps(decision))
    return 0


if __name__ == "__main__":
    sys.exit(main())
