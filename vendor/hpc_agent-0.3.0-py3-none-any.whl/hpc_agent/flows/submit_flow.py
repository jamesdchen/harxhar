"""``submit-flow``: workflow atom that does pre-flight + rsync + deploy + qsub + record.

A workflow atom (vs a primitive atom) chains multiple SSH/scheduler/disk
operations into one composable unit with a single envelope output. Where
:func:`hpc_agent.runner.submit_and_record` is the bookkeeping
primitive (writes a sidecar; never touches the cluster), ``submit_flow``
is the end-to-end pipeline: it actually rsyncs, deploys framework files,
optionally fires a 1-task canary, qsubs the array, and records to the
journal — emitting one JSON envelope at the end.

Why this exists: ``/campaign-hpc`` and other higher-level workflows
need to invoke the submit pipeline as a single CLI/Python call. The
slash-command surface (``/submit-hpc``) bundles interactive prompts
around this pipeline; the agent or another workflow can bypass the
prompts entirely by going straight to ``submit_flow``.

Idempotency
-----------
Idempotent on ``run_id`` — a replay returns ``deduped=True`` and
performs no SSH or scheduler side effects. The dedup check delegates
to :func:`runner.submit_and_record`, which has been the canonical
journal arbiter since the framework began.
"""

from __future__ import annotations

import contextlib
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from hpc_agent import errors, runner
from hpc_agent._internal import session
from hpc_agent._internal.primitive import SideEffect, primitive
from hpc_agent._schema_models.workflows.submit_flow import SubmitFlowSpec
from hpc_agent.infra.backends.sge_remote import RemoteSGEBackend
from hpc_agent.infra.backends.slurm_remote import RemoteSlurmBackend
from hpc_agent.infra.remote import deploy_runtime, rsync_push, ssh_run, validate_ssh_target
from hpc_agent.runner import submit_and_record

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from hpc_agent._schema_models.workflows.submit_flow_batch import SubmitFlowBatchSpec
    from hpc_agent.infra.backends import HPCBackend

__all__ = ["SubmitFlowResult", "submit_flow", "submit_flow_batch"]


@dataclass(frozen=True)
class SubmitFlowResult:
    """Return shape of :func:`submit_flow`."""

    run_id: str
    job_ids: list[str]
    total_tasks: int
    deduped: bool
    canary_done: bool
    canary_run_id: str | None = None
    canary_job_ids: list[str] | None = None

    def to_envelope_data(self) -> dict[str, Any]:
        """Render to the shape pinned by ``schemas/submit_flow.output.json``."""
        return {
            "run_id": self.run_id,
            "job_ids": list(self.job_ids),
            "total_tasks": self.total_tasks,
            "deduped": self.deduped,
            "canary_done": self.canary_done,
            "canary_run_id": self.canary_run_id,
            "canary_job_ids": list(self.canary_job_ids) if self.canary_job_ids else None,
        }


def _validate_ssh_target(ssh_target: str) -> str:
    """Wrap :func:`validate_ssh_target` to raise the surface-appropriate
    error type. The shared helper raises ``ValueError``; this flow
    surfaces ``SpecInvalid`` so callers see a typed envelope error.
    """
    try:
        return validate_ssh_target(ssh_target)
    except ValueError as exc:
        raise errors.SpecInvalid(str(exc)) from exc


def _build_backend(
    *,
    backend_name: str,
    script: str,
    ssh_target: str,
    remote_path: str,
    pass_env_keys: tuple[str, ...] | None,
    job_env_keys: tuple[str, ...],
    slurm_account: str | None = None,
    slurm_cluster: str | None = None,
) -> HPCBackend:
    """Construct the right HPCBackend for the requested scheduler.

    Both SGE and SLURM go through the cluster's login node via SSH —
    the local backends (which assume a local ``qsub``/``sbatch`` binary)
    are never used here. submit-flow is for laptop-driven submissions
    only.

    Callers MUST validate ``ssh_target`` before calling — both internal
    call sites (:func:`_submit_flow_batch_locked` for submit-flow,
    :func:`hpc_agent.flows.resubmit_flow._submit_resubmit_batches` for
    resubmit-flow) do so up-front so we avoid the wasteful duplicate
    validation that used to fire once per spec inside the per-spec loop.
    """

    def ssh(cmd: str):
        return ssh_run(cmd, ssh_target=ssh_target)

    if backend_name == "sge":
        keys = pass_env_keys if pass_env_keys is not None else job_env_keys
        return RemoteSGEBackend(
            script=script,
            ssh_run=ssh,
            remote_repo=remote_path,
            pass_env_keys=tuple(keys),
        )
    if backend_name == "slurm":
        return RemoteSlurmBackend(
            script=script,
            ssh_run=ssh,
            remote_repo=remote_path,
            account=slurm_account,
            cluster=slurm_cluster,
        )
    raise errors.SpecInvalid(f"unknown backend: {backend_name!r}")


def _preflight_probe(ssh_target: str, *, skip: bool) -> None:
    """Single ssh probe to verify cluster reachability. Caller may skip."""
    if skip:
        return
    probe = ssh_run("true", ssh_target=ssh_target)
    if probe.returncode != 0:
        raise errors.SshUnreachable(
            f"pre-flight ssh probe to {ssh_target} failed (exit {probe.returncode}): "
            f"{(probe.stderr or '').strip()[:200]}"
        )


def _push_and_deploy(
    *,
    experiment_dir: Path,
    ssh_target: str,
    remote_path: str,
    rsync_excludes: list[str] | None,
) -> None:
    """rsync_push + deploy_runtime — the expensive ssh fan-out, done once.

    Extracted so :func:`submit_flow_batch` can run it once across N
    specs that share ``(ssh_target, remote_path)``. The previous
    architecture re-ran both for every spec, which is what tripped
    cluster sshd MaxStartups under campaign-time fan-out (see commit
    0c99e1f / the SSH-backoff commit).
    """
    push_result = rsync_push(
        ssh_target=ssh_target,
        remote_path=remote_path,
        local_path=experiment_dir,
        exclude=rsync_excludes,
    )
    if push_result.returncode != 0:
        raise errors.RemoteCommandFailed(
            f"rsync push failed (exit {push_result.returncode}): "
            f"{(push_result.stderr or '').strip()[:300]}"
        )
    deploy_runtime(ssh_target=ssh_target, remote_path=remote_path)


def _augment_job_env(
    *,
    job_env: dict[str, str],
    runtime: str | None,
    campaign_id: str | None,
    cluster: str,
) -> dict[str, str]:
    """Layer the framework-driven env vars on top of the caller's job_env.

    Three augmentations: ``HPC_RUNTIME=uv`` when the spec asks for it,
    ``HPC_CAMPAIGN_ID`` when the run is part of a closed-loop campaign,
    and ``HPC_NFS_DATA_DIR`` from the cluster's ``nfs_data_dir`` setting
    (NFS-staging survival). Caller-supplied keys win via setdefault.
    """
    out = dict(job_env)
    if runtime == "uv":
        out.setdefault("HPC_RUNTIME", "uv")
    if campaign_id:
        out.setdefault("HPC_CAMPAIGN_ID", campaign_id)
    from hpc_agent.infra.clusters import get_nfs_data_dir, load_clusters_config

    cluster_cfg = load_clusters_config().get(cluster, {})
    try:
        nfs_dir = get_nfs_data_dir(cluster_cfg) if cluster_cfg else None
    except (ValueError, TypeError):
        nfs_dir = None
    if nfs_dir:
        out.setdefault("HPC_NFS_DATA_DIR", nfs_dir)
    return out


def _make_single_array_submission(
    backend: HPCBackend,
    *,
    job_name: str,
    total_tasks: int,
    job_env: dict[str, str],
    cwd: Path,
) -> list[str]:
    """Submit one array of size ``total_tasks`` and return the job IDs.

    Bypasses :class:`SubmissionPlan` for the simple case (no waves,
    no batching). Wave-based submissions are out of scope for v1 of
    submit-flow; callers needing them should use the legacy interactive
    ``/submit-hpc`` path or extend this function with a ``plan`` input.
    """
    backend._setup_log_dir()  # type: ignore[attr-defined]
    cmd = backend._build_command(  # type: ignore[attr-defined]
        f"1-{total_tasks}", job_name, job_env
    )
    result = backend._execute_command(cmd, job_env, cwd)  # type: ignore[attr-defined]
    if result.returncode != 0:
        stderr_msg = result.stderr.strip() if result.stderr else "(no stderr)"
        raise errors.RemoteCommandFailed(f"submit failed (exit {result.returncode}): {stderr_msg}")
    match = backend.JOB_ID_REGEX.search(result.stdout)
    if not match:
        raise errors.RemoteCommandFailed(
            f"could not parse job id from scheduler output: {result.stdout!r}"
        )
    return [match.group(1)]


@primitive(
    name="submit-flow",
    verb="workflow",
    # ``submit_and_record`` is the only atom this workflow actually invokes
    # at runtime. ``discover_executors`` is imported
    # for type hints / pre-submit advisory paths but not in the composition
    # itself; advertising it here previously made operations.json over-
    # promise the workflow's dependency graph.
    composes=[submit_and_record],
    side_effects=[
        SideEffect("sync-push", "<ssh_target>:<remote_path>"),
        SideEffect("scheduler-submit", "<cluster>"),
        SideEffect("writes-journal", "~/.claude/hpc/<repo_hash>/runs/<run_id>.json"),
    ],
    error_codes=[
        errors.SpecInvalid,
        errors.SshUnreachable,
        errors.SchedulerThrottled,
        errors.ClusterUnknown,
    ],
    idempotent=True,
    idempotency_key="run_id",
    exit_codes=[(0, "ok"), (1, "user-error"), (2, "cluster"), (3, "internal")],
    cli="hpc-agent submit-flow --spec <path>",
    agent_facing=True,
)
def submit_flow(
    experiment_dir: Path,
    *,
    spec: SubmitFlowSpec,
) -> SubmitFlowResult:
    """Execute the full submit pipeline and emit a single result.

    Pipeline:

    1. **Idempotency check** — if a journal record for ``spec.run_id``
       exists, return ``deduped=True`` immediately. No SSH, no scheduler
       calls.
    2. **Pre-flight gate** (skippable via ``spec.skip_preflight``) —
       verifies SSH agent forwarding + cluster reachability. Aborts on
       failure.
    3. **rsync_push** — sync ``experiment_dir`` to ``spec.remote_path``.
    4. **deploy_runtime** — scp framework files into
       ``<remote_path>/.hpc/``.
    5. **Optional canary** — submit a 1-task array (``job_name +
       "_canary"``, ``total_tasks=1``) and record it as a separate sidecar
       tagged with the same campaign. Caller waits and verifies — this
       atom only checks that qsub accepted the submission. Set
       ``spec.canary=False`` to skip when the caller has just
       smoke-tested.
    6. **Main submit** — qsub/sbatch the full ``1-total_tasks`` array.
    7. **Record** — :func:`runner.submit_and_record` writes the per-run
       sidecar + journal entry tagged with ``spec.campaign_id``.

    Errors raise the existing :class:`errors.HpcError` hierarchy so the
    CLI subcommand layer can convert them to error envelopes uniformly.

    ``spec.partial_ok`` records ``extra.partial_ok=True`` on the sidecar
    so a downstream monitor-flow wave with at least one success is
    classified ``complete`` (not ``failed``); aggregate-flow then skips
    the failed task IDs listed under ``<run_id>.failed.json``.
    """
    from hpc_agent._schema_models.workflows.submit_flow_batch import (
        SubmitFlowBatchSpec as _BatchSpec,
    )

    batch_spec = _BatchSpec(
        specs=[spec],
        rsync_excludes=spec.rsync_excludes,
        skip_preflight=spec.skip_preflight,
    )
    return submit_flow_batch(experiment_dir, spec=batch_spec)[0]


def _dedup_existing(experiment_dir: Path, spec: SubmitFlowSpec) -> SubmitFlowResult | None:
    """Return a deduped SubmitFlowResult if a journal record already exists."""
    existing = session.load_run(experiment_dir, spec.run_id)
    if existing is None:
        return None
    return SubmitFlowResult(
        run_id=existing.run_id,
        job_ids=list(existing.job_ids),
        total_tasks=int(existing.total_tasks),
        deduped=True,
        canary_done=False,
    )


def _submit_one_spec(
    *,
    experiment_dir: Path,
    spec: SubmitFlowSpec,
) -> SubmitFlowResult:
    """Per-spec submission work — backend build + (canary?) + main qsub + record.

    The expensive shared steps (preflight + rsync + deploy) MUST already
    have run on this ``(ssh_target, remote_path)`` before reaching here;
    :func:`submit_flow_batch` is responsible for that prelude.
    """
    job_env_full = _augment_job_env(
        job_env=spec.job_env,
        runtime=spec.runtime,
        campaign_id=spec.campaign_id,
        cluster=spec.cluster,
    )
    backend_obj = _build_backend(
        backend_name=spec.backend,
        script=spec.script,
        ssh_target=spec.ssh_target,
        remote_path=spec.remote_path,
        pass_env_keys=tuple(spec.pass_env_keys) if spec.pass_env_keys is not None else None,
        job_env_keys=tuple(job_env_full.keys()),
        slurm_account=spec.slurm_account,
        slurm_cluster=spec.slurm_cluster,
    )

    canary_run_id: str | None = None
    canary_job_ids: list[str] | None = None
    canary_done = False
    if spec.canary:
        canary_run_id = f"{spec.run_id}-canary"
        existing_canary = session.load_run(experiment_dir, canary_run_id)
        if existing_canary is not None:
            # Replay: a prior call landed the canary but failed before
            # recording the main run, so the main-run dedup check (keyed
            # on spec.run_id) misses it. Reuse the recorded canary
            # job_ids instead of firing a duplicate canary qsub —
            # submit_flow is documented idempotent on run_id.
            canary_job_ids = list(existing_canary.job_ids)
            canary_done = True
        else:
            canary_env = dict(job_env_full)
            canary_env["HPC_RUN_ID"] = canary_run_id
            canary_env["HPC_TASK_COUNT"] = "1"
            canary_job_ids = _make_single_array_submission(
                backend_obj,
                job_name=f"{spec.job_name}_canary",
                total_tasks=1,
                job_env=canary_env,
                cwd=experiment_dir,
            )
            from hpc_agent._schema_models.actions.submit import SubmitSpec as _SubmitSpec

            runner.submit_and_record(
                experiment_dir,
                spec=_SubmitSpec(
                    profile=spec.profile,
                    cluster=spec.cluster,
                    ssh_target=spec.ssh_target,
                    remote_path=spec.remote_path,
                    job_name=f"{spec.job_name}_canary",
                    run_id=canary_run_id,
                    job_ids=canary_job_ids,
                    total_tasks=1,
                    campaign_id=spec.campaign_id or None,
                ),
            )
            canary_done = True

    job_ids = _make_single_array_submission(
        backend_obj,
        job_name=spec.job_name,
        total_tasks=spec.total_tasks,
        job_env=job_env_full,
        cwd=experiment_dir,
    )
    from hpc_agent._schema_models.actions.submit import SubmitSpec as _SubmitSpec

    runner.submit_and_record(
        experiment_dir,
        spec=_SubmitSpec(
            profile=spec.profile,
            cluster=spec.cluster,
            ssh_target=spec.ssh_target,
            remote_path=spec.remote_path,
            job_name=spec.job_name,
            run_id=spec.run_id,
            job_ids=job_ids,
            total_tasks=spec.total_tasks,
            campaign_id=spec.campaign_id or None,
        ),
    )

    if spec.partial_ok:
        from hpc_agent.state.runs import run_sidecar_path

        marker = run_sidecar_path(experiment_dir, spec.run_id).with_suffix(".partial_ok")
        with contextlib.suppress(OSError):
            marker.write_text("1")

    return SubmitFlowResult(
        run_id=spec.run_id,
        job_ids=job_ids,
        total_tasks=spec.total_tasks,
        deduped=False,
        canary_done=canary_done,
        canary_run_id=canary_run_id,
        canary_job_ids=canary_job_ids,
    )


@primitive(
    name="submit-flow-batch",
    verb="workflow",
    # ``submit_and_record`` is the only atom this workflow actually invokes
    # at runtime. ``discover_executors`` is imported
    # for type hints / pre-submit advisory paths but not in the composition
    # itself; advertising it here previously made operations.json over-
    # promise the workflow's dependency graph.
    composes=[submit_and_record],
    side_effects=[
        SideEffect("sync-push", "<ssh_target>:<remote_path>"),
        SideEffect("scheduler-submit", "<cluster> (one qsub per spec)"),
        SideEffect("writes-journal", "~/.claude/hpc/<repo_hash>/runs/<run_id>.json (per spec)"),
    ],
    error_codes=[
        errors.SpecInvalid,
        errors.SshUnreachable,
        errors.SchedulerThrottled,
        errors.ClusterUnknown,
    ],
    idempotent=True,
    idempotency_key="specs.run_id",
    exit_codes=[(0, "ok"), (1, "user-error"), (2, "cluster"), (3, "internal")],
    cli="hpc-agent submit-flow-batch --spec <path>",
    agent_facing=True,
)
def submit_flow_batch(
    experiment_dir: Path,
    *,
    spec: SubmitFlowBatchSpec,
) -> list[SubmitFlowResult]:
    """Submit N specs that share ``(ssh_target, remote_path)`` in one shot.

    The Pydantic ``SubmitFlowBatchSpec`` is the canonical wire +
    Python authoring surface; ``spec.specs`` is a list of full
    :class:`SubmitFlowSpec` models (the same type the standalone
    ``submit-flow`` atom takes). ``spec.rsync_excludes`` and
    ``spec.skip_preflight`` apply once across the bundle.

    The motivating problem: a campaign-time fan-out of N submissions
    used to do N × (rsync + deploy_runtime + qsub), which sent ~13×N
    ssh handshakes at the cluster's sshd and tripped MaxStartups
    (CARC, typically). The bundle collapses that to:

    * 1 ssh probe (preflight)
    * 1 ``rsync_push`` (the codebase is identical across specs)
    * 1 ``deploy_runtime`` (the framework files are identical across specs)
    * N × (qsub + ``submit_and_record``) — sequential, but reusing the
      ssh ControlMaster socket established by the probe, so each
      additional qsub is ~free.

    Specs that already have a journal record are deduped up front and
    contribute a ``deduped=True`` :class:`SubmitFlowResult` without any
    cluster traffic — the same idempotency contract :func:`submit_flow`
    has always offered, applied per-spec.

    ``spec.specs`` MUST share ``ssh_target`` and ``remote_path`` —
    different targets/paths can't share an rsync. Heterogeneous batches
    raise :class:`errors.SpecInvalid`; the caller (campaign driver /
    agent) is responsible for grouping specs by ``(ssh_target,
    remote_path)`` before calling.

    Order of returned results matches the order of ``spec.specs``.
    """
    rsync_excludes = list(spec.rsync_excludes) if spec.rsync_excludes is not None else None
    skip_preflight = spec.skip_preflight if spec.skip_preflight is not None else False
    inner_specs = list(spec.specs)

    # Per-repo advisory submit lock: serialize multiple `submit-flow` /
    # `submit-flow-batch` invocations against the same experiment so two
    # shells firing simultaneously don't BOTH fan out N qsubs at the
    # cluster's sshd. The lock is advisory (other code paths don't take
    # it) and per-repo (`<journal_home>/.submit_lock`); cross-cluster
    # parallelism is still allowed when each cluster has its own
    # experiment_dir. Disable via ``HPC_SUBMIT_NO_LOCK=1`` — kept
    # narrowly for (a) the test suite, which exercises submit_flow in
    # parallel with mocked subprocess so there's no real qsub to race,
    # and (b) operators who deliberately want concurrent submits and
    # have confirmed the cluster's sshd / scheduler tolerates the
    # burst. Disabling outside those two cases risks a scheduler-
    # throttling stampede; see ``docs/reference/env-vars.md``.
    import os

    from hpc_agent._internal import io, session

    use_lock = os.environ.get("HPC_SUBMIT_NO_LOCK") != "1"
    lock_path = session.journal_dir(experiment_dir) / ".submit_lock"
    lock_ctx = io.advisory_flock(lock_path) if use_lock else _noop_lock_ctx()
    with lock_ctx:
        return _submit_flow_batch_locked(
            experiment_dir=experiment_dir,
            specs=inner_specs,
            rsync_excludes=rsync_excludes,
            skip_preflight=skip_preflight,
        )


@contextlib.contextmanager
def _noop_lock_ctx() -> Iterator[bool]:
    """Stand-in for advisory_flock when HPC_SUBMIT_NO_LOCK=1."""
    yield True


def _submit_flow_batch_locked(
    *,
    experiment_dir: Path,
    specs: list[SubmitFlowSpec],
    rsync_excludes: list[str] | None,
    skip_preflight: bool,
) -> list[SubmitFlowResult]:
    """Body of :func:`submit_flow_batch`, executed under the per-repo lock."""
    # Auto-cleanup: drop sidecars from earlier failed batches before doing
    # anything else. Without this, a half-baked sidecar from yesterday's
    # rate-limited submit would still surface to find_run_by_cmd_sha and
    # to the agent's resume-detection prompts. The prune is silent on
    # success (returns []); if it deletes anything, the cluster traffic
    # we're about to send is fresh anyway.
    from hpc_agent.state.runs import prune_orphan_sidecars

    prune_orphan_sidecars(experiment_dir)

    # Single-target invariant: rsync + deploy can only target one place.
    targets = {(s.ssh_target, s.remote_path) for s in specs}
    if len(targets) > 1:
        raise errors.SpecInvalid(
            f"submit_flow_batch requires all specs to share (ssh_target, remote_path); "
            f"got {len(targets)} distinct combinations: {sorted(targets)}"
        )

    # Per-spec idempotency: dedup against the journal up front, never
    # touch the cluster for already-submitted run_ids.
    results: list[SubmitFlowResult | None] = [_dedup_existing(experiment_dir, s) for s in specs]
    fresh_indices = [i for i, r in enumerate(results) if r is None]
    if not fresh_indices:
        # Every spec was already on the journal — return the deduped
        # results without firing rsync/deploy. ``# type: ignore`` would
        # otherwise be needed because mypy can't see the None elimination.
        return [r for r in results if r is not None]

    # Shared prelude: one ssh probe, one rsync, one deploy. This is the
    # whole point of the batch — collapse N × (probe + rsync + deploy)
    # into 1 × (probe + rsync + deploy), then fire N qsubs reusing the
    # ssh ControlMaster.
    ssh_target, remote_path = next(iter(targets))
    _validate_ssh_target(ssh_target)
    _preflight_probe(ssh_target, skip=skip_preflight)
    _push_and_deploy(
        experiment_dir=experiment_dir,
        ssh_target=ssh_target,
        remote_path=remote_path,
        rsync_excludes=rsync_excludes,
    )

    # Per-spec submission work.
    #
    # If spec ``i`` raises mid-loop, specs ``0..i-1`` are already on the
    # cluster (qsubbed AND journal-recorded by submit_and_record); we
    # can't recall them. Attach the partial result list to the
    # exception so the caller can recover state (which run_ids landed,
    # which to retry) instead of getting a bare raise with no
    # accounting.
    for i in fresh_indices:
        try:
            results[i] = _submit_one_spec(experiment_dir=experiment_dir, spec=specs[i])
        except Exception as exc:
            # Mutate the exception to carry the partial results. The
            # caller can branch on ``hasattr(exc, "partial_submit_results")``
            # to recover the (succeeded, failed_index) split.
            partial = [r for r in results if r is not None]
            exc.partial_submit_results = partial  # type: ignore[attr-defined]
            exc.failed_spec_index = i  # type: ignore[attr-defined]
            raise
    # mypy: every slot is now non-None.
    return [r for r in results if r is not None]
